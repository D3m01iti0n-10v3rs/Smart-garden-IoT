#include "actuators.h"

void SIPO_setup(){
    pinMode(SER, OUTPUT);
    pinMode(RCLK, OUTPUT);
    pinMode(SRCLK, OUTPUT);
    digitalWrite(SER, 0);
    digitalWrite(RCLK, 0);
    digitalWrite(SRCLK, 0);
}

void SIPO_write(uint8_t data){
    for (uint8_t i = 0; i < 8; i++){
        digitalWrite(SER, (data >> 7) & 1);
        data <<= 1;

        digitalWrite(SRCLK, 1);
        digitalWrite(SRCLK, 0);
    }
    digitalWrite(RCLK, 1);
    digitalWrite(RCLK, 0);
}