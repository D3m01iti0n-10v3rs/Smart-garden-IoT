#ifndef ACTUATORS_H
#define ACTUATORS_H

#include <Arduino.h>

#define SER 19
#define RCLK 18
#define SRCLK 5

void SIPO_setup();
void SIPO_write(uint8_t data);

#endif