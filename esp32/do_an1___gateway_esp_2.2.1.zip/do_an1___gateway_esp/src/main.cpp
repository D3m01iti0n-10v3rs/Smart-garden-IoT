#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <ESPmDNS.h>
#include "server_client.h"

const char*    WIFI_SSID = "Xom Tro";
const char*    WIFI_PASS = "xomtro247";
const char*    WS_HOST = "gloriainexcelsisdeo";
const int      WS_PORT   = 3000;
const char*    WS_PATH   = "/ws";

const char* CONF1_SSID = "For God so loved the world";
const char* CONF1_PASS = "77777777";

const char* CONF2_SSID = "That whosoever believeth in him";
const char* CONF2_PASS = "77777777";

WebServer configServer1(80);
WebServer configServer2(80);
 
String savedSSID = "";
String savedPass = "";
bool credsSaved = false;
 
void handleRoot() {
  configServer1.send(200, "text/html",
    "<!DOCTYPE html><html><head>"
    "<meta name='viewport' content='width=device-width, initial-scale=1'>"
    "<style>"
    "body{font-family:Arial,sans-serif;background:#f4f7fb;margin:0;padding:24px;}"
    ".card{max-width:360px;margin:auto;background:#fff;padding:24px;border-radius:12px;"
    "box-shadow:0 4px 16px rgba(0,0,0,0.08);}"
    "h2{margin-top:0;color:#1f2937;}"
    "label{display:block;margin:12px 0 6px;color:#374151;font-size:14px;}"
    "input,select{width:100%;padding:10px;border:1px solid #d1d5db;border-radius:8px;box-sizing:border-box;}"
    "button{width:100%;margin-top:16px;padding:10px;border:0;border-radius:8px;"
    "background:#2563eb;color:#fff;font-size:15px;}"
    "</style></head><body>"
    "<div class='card'>"
    "<h2>WiFi Setup</h2>"
    "<form method='POST' action='/save'>"
    "<label>SSID</label><select name='ssid'>"
    + ([]() {
        String s = "";
        int n = WiFi.scanNetworks();

        for (int i = 0; i < n; i++) {
          s += "<option value='";
          s += WiFi.SSID(i);
          s += "'>";
          s += WiFi.SSID(i);
          s += " (";
          s += WiFi.RSSI(i);
          s += " dBm)</option>";
        }

        WiFi.scanDelete();
        return s;
      })()
    + "</select>"
    "<label>Password</label><input name='pass' type='password'>"
    "<button type='submit'>Save</button>"
    "</form>"
    "</div></body></html>"
  );
}
 
void handleSave() {
  savedSSID  = configServer1.arg("ssid");
  savedPass  = configServer1.arg("pass");
  credsSaved = true;
  configServer1.send(200, "text/html",
    "<html><body style='font-family:Arial;padding:20px;'>"
    "<h3>Saved. Connecting...</h3>"
    "<p>You can now close this page.</p>"
    "</body></html>"
  );
}

void handleCreds() {
  String json =
    "{"
    "\"ssid\":\"" + savedSSID + "\","
    "\"pass\":\"" + savedPass + "\""
    "}";

  configServer2.send(200, "application/json", json);
}

bool camAck = false;
bool serverAck = false;
void handleACK() {
  String device = configServer2.arg("device");

  if (device == "cam") {
    camAck = true;
    Serial.printf("[CONF2] CAM ACK\r\n");
  }
  if (device == "server") {
    serverAck = true;
    Serial.printf("[CONF2] SERVER ACK\r\n");
  }
  configServer2.send(200, "text/plain", "OK");
}

bool syncFailed = false;
void handleNACK() {
  String device = configServer2.arg("device");

  syncFailed = true;
  if (device == "cam") {
    camAck = false;
    Serial.printf("[CONF2] CAM NACK\r\n");
  }
  if (device == "server") {
    serverAck = false;
    Serial.printf("[CONF2] SERVER NACK\r\n");
  }
  configServer2.send(200, "text/plain", "OK");
}

//uint8_t devices_reg = 0;
//volatile uint8_t cmd_available = 0;
//uint8_t pending_cmd = 0xAA;

//SemaphoreHandle_t wifi_mutex;
//SemaphoreHandle_t devices_mutex;
//SemaphoreHandle_t serial2_mutex;

void server_coms_task(void * parameter){
  uint8_t deviceState = 0;
  for(;;){
    server_loop();
    server_insert_sensor("temperature", random(200, 350) / 10.0f);
    server_insert_sensor("humidity", random(0, 100) / 1.0f);
    server_get_devices();
    deviceState ^= 1;
    server_update_device("1", deviceState ^ 1);
    vTaskDelay(pdMS_TO_TICKS(5000));
  }
}

void on_device_update(const char* deviceID, int value) {
    Serial.printf("device %s -> %d\n", deviceID, value);
}

void on_response(JsonDocument& doc) {
    const char* type = doc["type"];
    if (strcmp(type, "sensors.data") == 0) {
        JsonArray rows = doc["rows"];
        for (JsonObject row : rows)
            Serial.printf("%s = %.2f\n", row["type"].as<const char*>(), row["value"].as<float>());
    }
}

/*
void wifi_task(void * parameter){
  uint8_t attempt = 0;
  WiFi.begin(ssid, password);

  for(;;){
    uint8_t status = WiFi.status();
    xSemaphoreTake(wifi_mutex, portMAX_DELAY);
    wifi_connected = status;
    xSemaphoreGive(wifi_mutex);

    if (status != WL_CONNECTED){
      if (attempt == 20){
        attempt = 0;
        Serial.printf("Connecting to %s failed. Retrying\n", ssid);
        WiFi.begin(ssid, password);
        vTaskDelay(pdMS_TO_TICKS(500));
      } else {
        attempt++;
        Serial.printf("Connecting to %s\n", ssid);
        vTaskDelay(pdMS_TO_TICKS(500));
      }
    } else {
      Serial.printf("Connected to %s\n", ssid);
      vTaskDelay(pdMS_TO_TICKS(10000));
    }
  }
}

void sensor_task(void * parameter) {
  String data;
  vTaskDelay(pdMS_TO_TICKS(10000));
  for (;;) {
    xSemaphoreTake(serial2_mutex, portMAX_DELAY);

    while (Serial2.available()) Serial2.read();
    Serial2.printf("REQ SENSOR\r\n");
    Serial.printf("Serial2 SENT: REQ SENSOR\r\n");

    uint32_t t = millis();
    while (!Serial2.available()) {
      if (millis() - t > 5000) {
        Serial.println("Sensor request timed out");
        xSemaphoreGive(serial2_mutex);
        goto sensor_timeout;
      }
      vTaskDelay(pdMS_TO_TICKS(10));
    }

    data = Serial2.readStringUntil('\n');
    data.trim();

    float s[4];
    sscanf(data.c_str(), "%f,%f,%f,%f", &s[0], &s[1], &s[2], &s[3]);
    Serial.printf("Sensors: %.2f %.2f %.2f %.2f\n", s[0], s[1], s[2], s[3]);
    // TODO: send sensor data to server
    xSemaphoreGive(serial2_mutex);

    sensor_timeout:
    vTaskDelay(pdMS_TO_TICKS(10000));
  }
}

void cmd_task(void * parameter) {
  String data;
  vTaskDelay(pdMS_TO_TICKS(10000));
  for (;;) {
    //if (cmd_available) {
    if (1) {
      cmd_available = 0;
      xSemaphoreTake(serial2_mutex, portMAX_DELAY);

      while (Serial2.available()) Serial2.read();
      Serial2.print("REQ CMD\r\n");
      Serial.printf("Serial2 SENT: REQ CMD\r\n");

      uint32_t t = millis();
      while (!Serial2.available()) {
        if (millis() - t > 3000) {
          Serial.println("CMD ACK timed out");
          xSemaphoreGive(serial2_mutex);
          goto cmd_timeout;
        }
        vTaskDelay(pdMS_TO_TICKS(10));
      }
      data = Serial2.readStringUntil('\n');
      data.trim();
      //Serial.printf("UART2 received: %s\n", data.c_str());

      if (data == "ACK") {
        Serial2.write(pending_cmd);
        Serial.printf("Serial2 SENT: 0x%02X\n", pending_cmd);

        t = millis();
        while (!Serial2.available()) {
          if (millis() - t > 3000) {
            Serial.println("EXE OK timed out");
            xSemaphoreGive(serial2_mutex);
            goto cmd_timeout;
          }
          vTaskDelay(pdMS_TO_TICKS(10));
        }
        data = Serial2.readStringUntil('\n');
        data.trim();

        if (data == "EXE OK") {
          Serial.println("STM executed command");
          // TODO: update server database
        }
      }

      xSemaphoreGive(serial2_mutex);
      cmd_timeout:;
    }
    //vTaskDelay(pdMS_TO_TICKS(10));
    vTaskDelay(pdMS_TO_TICKS(10000));
  }
}
*/

void setup() {
  Serial.begin(115200);
  Serial2.begin(115200, SERIAL_8N1, 16, 17);

  /*
  configServer1.on("/",     HTTP_GET,  handleRoot);
  configServer1.on("/save", HTTP_POST, handleSave);

  configServer2.on("/creds", HTTP_GET, handleCreds);
  configServer2.on("/ack", HTTP_POST, handleACK);
  configServer2.on("/nack", HTTP_POST, handleNACK);

  AP1:
  syncFailed = false;
  camAck = false;
  serverAck = false;

  IPAddress apIP(10, 0, 0, 1);
  IPAddress apGateway(10, 0, 0, 1);
  IPAddress apSubnet(255, 255, 255, 0);

  while (1) {
    credsSaved = false;
    
    WiFi.mode(WIFI_AP_STA);
    WiFi.softAPConfig(apIP, apGateway, apSubnet);
    WiFi.softAP(CONF1_SSID, CONF1_PASS);
    Serial.printf("[BOOT] AP conf1: http://%s\n", WiFi.softAPIP().toString().c_str());
    configServer1.begin();

    while (!credsSaved) {
      configServer1.handleClient();
      delay(10);
    }

    configServer1.stop();
    WiFi.softAPdisconnect(true);

    bool connected = false;

    for (int attempt = 1; attempt <= 3; attempt++) {

      Serial.printf("[WIFI] Attempt %d connecting to %s\n",
        attempt,
        savedSSID.c_str());

      WiFi.begin(savedSSID.c_str(), savedPass.c_str());

      uint32_t start = millis();
      while (millis() - start < 10000) {

        if (WiFi.status() == WL_CONNECTED) {
          connected = true;
          break;
        }

        delay(500);
        Serial.print(".");
      }

      if (connected) break;

      Serial.println("\n[WIFI] Connection failed");
      WiFi.disconnect(true);
    }

    if (connected) {
      Serial.printf("\n[WIFI] Connected, IP: %s\n",
        WiFi.localIP().toString().c_str());
      break;
    }

    Serial.println("[WIFI] All attempts failed, reopening config AP");
  }

  WiFi.disconnect(false);
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAPConfig(apIP, apGateway, apSubnet);
  WiFi.softAP(CONF2_SSID, CONF2_PASS);
  Serial.printf("[BOOT] AP conf2: http://%s\n", WiFi.softAPIP().toString().c_str());

  configServer2.begin();

  while (!(camAck && serverAck) && !syncFailed) {
    configServer2.handleClient();
    delay(10);
  }

  if (syncFailed) {
    Serial.println("[SYNC] Device reported failure");
    configServer2.stop();
    WiFi.softAPdisconnect(true);
    goto AP1;
  }

  Serial.println("[SYNC] All devices connected");

  configServer2.stop();
  WiFi.softAPdisconnect(true);
  WiFi.disconnect(true, true);

  delay(5000);

  WiFi.mode(WIFI_STA);
  WiFi.config(INADDR_NONE, INADDR_NONE, INADDR_NONE);
  Serial.printf("[WIFI] Reconnecting to %s\n", savedSSID.c_str());
  WiFi.begin(savedSSID.c_str(), savedPass.c_str());
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.printf("\n[WIFI] Connected, IP: %s\n", WiFi.localIP().toString().c_str());
  */
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  Serial.print("[WiFi] Connecting");
  while (WiFi.status() != WL_CONNECTED) {delay(500); Serial.print(".");}
  Serial.printf("\n[WiFi] IP: %s\n", WiFi.localIP().toString().c_str());

  if (!MDNS.begin("esp32_gateway")) {
    Serial.println("MDNS init failed");
    return;
  }

  server_connect(WS_HOST, WS_PORT);

  //wifi_mutex = xSemaphoreCreateMutex();
  //devices_mutex = xSemaphoreCreateMutex();
  //serial2_mutex = xSemaphoreCreateMutex();

  //xTaskCreate(wifi_task, "wifi_task", 4096, NULL, 2, NULL);
  //xTaskCreate(sensor_task, "sensor_task", 4096, NULL, 1, NULL);
  //xTaskCreate(cmd_task, "cmd_task", 2048, NULL, 1, NULL);
  xTaskCreate(server_coms_task, "server_coms_task", 4096, NULL, 3, NULL);
}

void loop() {}