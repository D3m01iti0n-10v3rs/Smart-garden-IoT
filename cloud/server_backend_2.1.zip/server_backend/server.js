const http = require("http");
const { WebSocketServer } = require("ws");
const sqlite3 = require("sqlite3").verbose();

// ── Database ──────────────────────────────────────────────────────────────────

const db = new sqlite3.Database("./database.db");

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS sensors (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    type      TEXT,
    value     REAL,
    timestamp DATETIME
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS devices (
    deviceID   TEXT UNIQUE,
    state      INTEGER DEFAULT 0,
    updated_at DATETIME
  )`);

  for (let i = 1; i <= 8; i++) {
    db.run(`INSERT OR IGNORE INTO devices (deviceID, state, updated_at) VALUES (?, 0, datetime('now', 'localtime'))`, [String(i)]);
  }
});

// ── State ─────────────────────────────────────────────────────────────────────

let latestFrame = null;
let camSocket   = null;
const wsClients = new Set();

// ── Helpers ───────────────────────────────────────────────────────────────────

function send(ws, obj) {
  if (ws.readyState === ws.OPEN) ws.send(JSON.stringify(obj));
}

function broadcast(obj) {
  const msg = JSON.stringify(obj);
  for (const client of wsClients) {
    if (client.readyState === client.OPEN) client.send(msg);
  }
}

// ── WebSocket servers (noServer = true, routed manually below) ────────────────

const wss_cam = new WebSocketServer({ noServer: true });
const wss_ws  = new WebSocketServer({ noServer: true });

// /cam — ESP32-CAM
wss_cam.on("connection", (ws, req) => {
  console.log("[CAM] Connected from", req.socket.remoteAddress);
  camSocket = ws;

  ws.on("message", (data, isBinary) => {
    if (!isBinary) return;
    latestFrame = data;
    for (const client of wsClients) {
      if (client.readyState === client.OPEN) client.send(data);
    }
  });

  ws.on("close", () => {
    console.log("[CAM] Disconnected");
    camSocket   = null;
    latestFrame = null;
    broadcast({ type: "camera.disconnected" });
  });

  ws.on("error", (err) => console.error("[CAM] error:", err.message));
});

// /ws — GUI clients + sensor ESP
wss_ws.on("connection", (ws) => {
  console.log("[WS] Client connected, total:", wsClients.size + 1);
  wsClients.add(ws);

  if (latestFrame) ws.send(latestFrame);

  ws.on("message", (data, isBinary) => {
    if (isBinary) return;

    let msg;
    try { msg = JSON.parse(data.toString()); }
    catch { return send(ws, { type: "error", message: "Invalid JSON" }); }

    switch (msg.type) {

      case "sensors.insert": {
          const client = ws;
          db.run("INSERT INTO sensors (type, value, timestamp) VALUES (?, ?, datetime('now', 'localtime'))",
              [msg.sensorType, msg.value],
              (err) => err ? send(client, { type: "error", message: err.message })
                          : send(client, { type: "ok" }));
          break;
      }

      case "sensors.get":
        db.all("SELECT * FROM sensors ORDER BY timestamp DESC LIMIT 50", [],
          (err, rows) => err ? send(ws, { type: "error", message: err.message })
                             : send(ws, { type: "sensors.data", rows }));
        break;

      case "devices.get":
        db.all("SELECT * FROM devices ORDER BY deviceID ASC", [],
          (err, rows) => err ? send(ws, { type: "error", message: err.message })
                             : send(ws, { type: "devices.data", rows }));
        break;

      case "devices.update": {
          const client = ws; // capture before async callback
          db.run("UPDATE devices SET state = ?, updated_at = datetime('now', 'localtime') WHERE deviceID = ?",
              [msg.value, msg.deviceID],
              (err) => {
                  if (err) return send(client, { type: "error", message: err.message });
                  send(client, { type: "ok" });
              });
          break;
      }

      case "camera.settings": {
        if (!camSocket || camSocket.readyState !== camSocket.OPEN)
          return send(ws, { type: "error", message: "Camera not connected" });
        const allowed = ["framesize","quality","vflip","hmirror","brightness","contrast","saturation"];
        const settings = {};
        for (const k of allowed) if (msg[k] !== undefined) settings[k] = msg[k];
        if (!Object.keys(settings).length)
          return send(ws, { type: "error", message: "No valid settings" });
        camSocket.send(JSON.stringify(settings), (err) =>
          err ? send(ws, { type: "error", message: "Failed to send to camera" })
              : send(ws, { type: "ok", applied: settings }));
        break;
      }

      case "frame.get":
        if (!latestFrame) return send(ws, { type: "error", message: "No frame yet" });
        ws.send(latestFrame);
        break;

      default:
        send(ws, { type: "error", message: `Unknown type: ${msg.type}` });
    }
  });

  ws.on("close", () => {
    wsClients.delete(ws);
    console.log("[WS] Client disconnected, total:", wsClients.size);
  });

  ws.on("error", (err) => console.error("[WS] error:", err.message));
});

// ── HTTP server — routes upgrades to the correct WSS ─────────────────────────

const server = http.createServer();

server.on("upgrade", (req, socket, head) => {
  if (req.url === "/cam") {
    wss_cam.handleUpgrade(req, socket, head, (ws) => wss_cam.emit("connection", ws, req));
  } else if (req.url === "/ws") {
    wss_ws.handleUpgrade(req, socket, head, (ws) => wss_ws.emit("connection", ws, req));
  } else {
    socket.destroy();
  }
});

server.listen(3000, () => {
  console.log("Listening on port 3000");
  console.log("Camera  : ws://localhost:3000/cam");
  console.log("Clients : ws://localhost:3000/ws");

  const mdns = require('multicast-dns')();

  mdns.on('query', function(query) {
    query.questions.forEach((q) => {
      if (q.name === 'gloriainexcelsisdeo.local' && q.type === 'A'){
        mdns.respond({
          answers: [{
            name: 'gloriainexcelsisdeo.local',
            type: 'A',
            ttl: 300,
            data: '192.168.1.64'
          }]
        });
        console.log('Responded to mDNS query');
      }
    });
  });
});